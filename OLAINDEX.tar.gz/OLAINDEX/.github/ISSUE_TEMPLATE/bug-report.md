---
name: 问题反馈
about: 关于OLAINDEX出现的问题与建议
title: ''
labels: bug
assignees: WangNingkai

---

### 1. 该问题的重现步骤是什么？

### 2. 你期待的结果是什么？实际看到的又是什么？

### 3. 问题出现的环境

- 操作系统版本：
- Apache/NGINX 版本：
- PHP 版本：
- OLAINDEX 版本：
- 浏览器版本：

[//]: # (如有图片请附上截图)
