<div class="text-center">
    <iframe width="100%" src="{{ $file['preview'] }}" style="height: 41em; border: 0px;"></iframe>
</div>
