<div class="text-center">
    <a href="{{ $file['download'] }}">
        <img width="100px" height="100px" src="{{ asset('img/file.png') }}" alt="{{ $file['name'] }}" class="img-fluid">
    </a>
</div>
