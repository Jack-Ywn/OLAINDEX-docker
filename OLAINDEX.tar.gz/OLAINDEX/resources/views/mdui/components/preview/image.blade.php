<img class="mdui-img-fluid mdui-center" src="{{ $file['thumb'] ?? $file['download'] }}" alt="{{ $file['name'] }}"/>
