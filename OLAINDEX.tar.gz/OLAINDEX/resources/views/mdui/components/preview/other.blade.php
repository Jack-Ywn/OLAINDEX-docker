<img class="mdui-center mdui-valign" height="200px" src="{{ asset('img/file.png') }}" alt="{{ $file['name'] }}"/>
